import * as React from 'react';
// import Counter from '../Counter/Counter';

export default class App extends React.Component {
  render() {
    return (
      <div>
        <h1>Hello!</h1>
      </div>
    );
  }
}
