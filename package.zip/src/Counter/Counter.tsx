import * as React from 'react';

export default class Counter extends React.Component {

  public state: { count: number };

  constructor(props: {}) {
    super(props);
    this.state = { count: 0 };
  }

  render() {
    return (
      <span>
        The counter is at ${this.state.count};
      </span>
    );
  }
}