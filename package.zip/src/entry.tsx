// import * as React from 'react';
// import * as ReactDOM from 'react-dom';

// import App from './Home/App';

// console.log('HELLO');

// ReactDOM.render(
//   <App />,
//   document.getElementById('app-root')
// );

console.log('Hello');
