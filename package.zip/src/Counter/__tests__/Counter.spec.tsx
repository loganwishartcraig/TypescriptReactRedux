import * as React from 'react';
import { shallow } from 'enzyme';

import Counter from '../Counter';

describe('Component - Counter', () => {

  it('Renders', () => {

    const result = shallow(<Counter/>);
    expect(result).toBeTruthy();

  });

});
